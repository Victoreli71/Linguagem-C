
// Exercício 2
#include <stdio.h>

int main() {
    int x, y;
    printf("Digite o primeiro número inteiro positivo: ");
    scanf("%d", &x);
    printf("Digite o segundo número inteiro positivo: ");
    scanf("%d", &y);

    if (x == y) {
        printf("O número %d é igual ao número %d\n", x, y);
    } else if (x > y) {
        printf("O número %d é maior que o número %d\n", x, y);
    } else {
        printf("O número %d é menor que o número %d\n", x, y);
    }

    return 0;
}
