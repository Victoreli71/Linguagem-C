
// Exercício 1
#include <stdio.h>

int main() {
    int numero;
    printf("Digite um número inteiro positivo: ");
    scanf("%d", &numero);

    if (numero % 3 == 0) {
        printf("O número %d é múltiplo de 3\n", numero);
    }

    return 0;
}
