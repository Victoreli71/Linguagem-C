
// Exercício 3
#include <stdio.h>

int main() {
    int opcao;
    printf("Entre com uma opção de título de livros:\n1 - Infantil\n2 - Ficção\n3 - Suspense\n4 - Aventura\nOpção: ");
    scanf("%d", &opcao);

    switch (opcao) {
        case 1:
            printf("Você escolheu Infantil.\n");
            break;
        case 2:
            printf("Você escolheu Ficção.\n");
            break;
        case 3:
            printf("Você escolheu Suspense.\n");
            break;
        case 4:
            printf("Você escolheu Aventura.\n");
            break;
        default:
            printf("Opção inválida.\n");
    }

    return 0;
}
