
// Exercício 10
#include <stdio.h>

int main() {
    int i;
    for (i = 10; i >= 1; i--) {
        printf("%d\n", i);
    }
    printf("Fogo!\n");

    return 0;
}
